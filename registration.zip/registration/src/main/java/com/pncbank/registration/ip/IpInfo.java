package com.pncbank.registration.ip;

import lombok.Data;

@Data
public class IpInfo {
    private String city;
    private String country;
}
