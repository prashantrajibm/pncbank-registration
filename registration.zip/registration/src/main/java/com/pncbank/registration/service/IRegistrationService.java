package com.pncbank.registration.service;

import com.pncbank.registration.dto.UserDto;

public interface IRegistrationService {

    String registerUser(UserDto userDto);

}

